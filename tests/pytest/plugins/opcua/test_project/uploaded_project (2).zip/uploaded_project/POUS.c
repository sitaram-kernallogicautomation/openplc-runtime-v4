void SENSORDATA_init__(SENSORDATA *data__, BOOL retain) {
  __INIT_VAR(data__->EN,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->ENO,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->SENSOR_ID,0,retain)
  __INIT_VAR(data__->VALUE,0,retain)
  __INIT_VAR(data__->IS_VALID,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->LOCAL_TEMP,0,retain)
}

// Code part
void SENSORDATA_body__(SENSORDATA *data__) {
  // Control execution
  if (!__GET_VAR(data__->EN)) {
    __SET_VAR(data__->,ENO,,__BOOL_LITERAL(FALSE));
    return;
  }
  else {
    __SET_VAR(data__->,ENO,,__BOOL_LITERAL(TRUE));
  }
  // Initialise TEMP variables

  __SET_VAR(data__->,LOCAL_TEMP,,0);

  goto __end;

__end:
  return;
} // SENSORDATA_body__() 





void POSITION3D_init__(POSITION3D *data__, BOOL retain) {
  __INIT_VAR(data__->EN,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->ENO,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->X,0,retain)
  __INIT_VAR(data__->Y,0,retain)
  __INIT_VAR(data__->Z,0,retain)
  __INIT_VAR(data__->LOCAL_TEMP,0,retain)
}

// Code part
void POSITION3D_body__(POSITION3D *data__) {
  // Control execution
  if (!__GET_VAR(data__->EN)) {
    __SET_VAR(data__->,ENO,,__BOOL_LITERAL(FALSE));
    return;
  }
  else {
    __SET_VAR(data__->,ENO,,__BOOL_LITERAL(TRUE));
  }
  // Initialise TEMP variables

  __SET_VAR(data__->,LOCAL_TEMP,,0);

  goto __end;

__end:
  return;
} // POSITION3D_body__() 





void DEVICESTATUS_init__(DEVICESTATUS *data__, BOOL retain) {
  __INIT_VAR(data__->EN,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->ENO,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->DEVICE_NAME,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->ERROR_CODE,0,retain)
  __INIT_VAR(data__->TEMPERATURE,0,retain)
  __INIT_VAR(data__->IS_ONLINE,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->UPTIME_SECONDS,0,retain)
  __INIT_VAR(data__->LOCAL_TEMP,0,retain)
}

// Code part
void DEVICESTATUS_body__(DEVICESTATUS *data__) {
  // Control execution
  if (!__GET_VAR(data__->EN)) {
    __SET_VAR(data__->,ENO,,__BOOL_LITERAL(FALSE));
    return;
  }
  else {
    __SET_VAR(data__->,ENO,,__BOOL_LITERAL(TRUE));
  }
  // Initialise TEMP variables

  __SET_VAR(data__->,LOCAL_TEMP,,0);

  goto __end;

__end:
  return;
} // DEVICESTATUS_body__() 





void MAIN_init__(MAIN *data__, BOOL retain) {
  __INIT_VAR(data__->SIMPLE_BOOL,__BOOL_LITERAL(FALSE),retain)
  __INIT_VAR(data__->SIMPLE_BOOL_TRUE,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->SIMPLE_BYTE,0,retain)
  __INIT_VAR(data__->SIMPLE_BYTE_MAX,255,retain)
  __INIT_VAR(data__->SIMPLE_INT,0,retain)
  __INIT_VAR(data__->SIMPLE_INT_NEGATIVE,-100,retain)
  __INIT_VAR(data__->SIMPLE_INT_MAX,32767,retain)
  __INIT_VAR(data__->SIMPLE_INT_MIN,-32768,retain)
  __INIT_VAR(data__->SIMPLE_DINT,0,retain)
  __INIT_VAR(data__->SIMPLE_DINT_LARGE,100000,retain)
  __INIT_VAR(data__->SIMPLE_DINT_NEGATIVE,-100000,retain)
  __INIT_VAR(data__->SIMPLE_LINT,0,retain)
  __INIT_VAR(data__->SIMPLE_LINT_LARGE,1000000000,retain)
  __INIT_VAR(data__->SIMPLE_REAL,0.0,retain)
  __INIT_VAR(data__->SIMPLE_REAL_PI,3.14159,retain)
  __INIT_VAR(data__->SIMPLE_REAL_NEGATIVE,-273.15,retain)
  __INIT_VAR(data__->SIMPLE_STRING,__STRING_LITERAL(0,""),retain)
  __INIT_VAR(data__->SIMPLE_STRING_HELLO,__STRING_LITERAL(12,"Hello OPC-UA"),retain)
  SENSORDATA_init__(&data__->SENSOR1,retain);
  __INIT_VAR(data__->SENSOR1.SENSOR_ID,1,retain)
  __INIT_VAR(data__->SENSOR1.VALUE,0.0,retain)
  __INIT_VAR(data__->SENSOR1.IS_VALID,__BOOL_LITERAL(FALSE),retain)
  SENSORDATA_init__(&data__->SENSOR2,retain);
  __INIT_VAR(data__->SENSOR2.SENSOR_ID,2,retain)
  __INIT_VAR(data__->SENSOR2.VALUE,25.5,retain)
  __INIT_VAR(data__->SENSOR2.IS_VALID,__BOOL_LITERAL(TRUE),retain)
  POSITION3D_init__(&data__->ROBOT_POSITION,retain);
  __INIT_VAR(data__->ROBOT_POSITION.X,0.0,retain)
  __INIT_VAR(data__->ROBOT_POSITION.Y,0.0,retain)
  __INIT_VAR(data__->ROBOT_POSITION.Z,0.0,retain)
  POSITION3D_init__(&data__->TARGET_POSITION,retain);
  __INIT_VAR(data__->TARGET_POSITION.X,100.0,retain)
  __INIT_VAR(data__->TARGET_POSITION.Y,50.0,retain)
  __INIT_VAR(data__->TARGET_POSITION.Z,25.0,retain)
  DEVICESTATUS_init__(&data__->PLC_STATUS,retain);
  __INIT_VAR(data__->PLC_STATUS.DEVICE_NAME,__STRING_LITERAL(7,"OpenPLC"),retain)
  __INIT_VAR(data__->PLC_STATUS.ERROR_CODE,0,retain)
  __INIT_VAR(data__->PLC_STATUS.TEMPERATURE,45.5,retain)
  __INIT_VAR(data__->PLC_STATUS.IS_ONLINE,__BOOL_LITERAL(TRUE),retain)
  __INIT_VAR(data__->PLC_STATUS.UPTIME_SECONDS,0,retain)
  {
    __SET_VAR(,data__->BOOL_ARRAY.value.table[0],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[1],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[2],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[3],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[4],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[5],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[6],,__BOOL_LITERAL(FALSE));
    __SET_VAR(,data__->BOOL_ARRAY.value.table[7],,__BOOL_LITERAL(FALSE));
  }
  {
    __SET_VAR(,data__->INT_ARRAY.value.table[0],,0);
    __SET_VAR(,data__->INT_ARRAY.value.table[1],,0);
    __SET_VAR(,data__->INT_ARRAY.value.table[2],,0);
    __SET_VAR(,data__->INT_ARRAY.value.table[3],,0);
    __SET_VAR(,data__->INT_ARRAY.value.table[4],,0);
  }
  {
    __SET_VAR(,data__->REAL_ARRAY.value.table[0],,0.0);
    __SET_VAR(,data__->REAL_ARRAY.value.table[1],,0.0);
    __SET_VAR(,data__->REAL_ARRAY.value.table[2],,0.0);
    __SET_VAR(,data__->REAL_ARRAY.value.table[3],,0.0);
  }
  {
    __SET_VAR(,data__->DINT_ARRAY.value.table[0],,0);
    __SET_VAR(,data__->DINT_ARRAY.value.table[1],,0);
    __SET_VAR(,data__->DINT_ARRAY.value.table[2],,0);
  }
  __INIT_VAR(data__->CYCLE_COUNTER,0,retain)
  __INIT_VAR(data__->TOGGLE_OUTPUT,__BOOL_LITERAL(FALSE),retain)
}

// Code part
void MAIN_body__(MAIN *data__) {
  // Initialise TEMP variables

  __SET_VAR(data__->,CYCLE_COUNTER,,(__GET_VAR(data__->CYCLE_COUNTER,) + 1));
  if ((__GET_VAR(data__->CYCLE_COUNTER,) >= 10)) {
    __SET_VAR(data__->,PLC_STATUS.UPTIME_SECONDS,,(__GET_VAR(data__->PLC_STATUS.UPTIME_SECONDS,) + 1));
    __SET_VAR(data__->,CYCLE_COUNTER,,0);
  };
  if ((((2 == 0)?0:(__GET_VAR(data__->PLC_STATUS.UPTIME_SECONDS,) % 2)) == 0)) {
    __SET_VAR(data__->,TOGGLE_OUTPUT,,__BOOL_LITERAL(TRUE));
  } else {
    __SET_VAR(data__->,TOGGLE_OUTPUT,,__BOOL_LITERAL(FALSE));
  };
  if (((__GET_VAR(data__->SENSOR1.VALUE,) >= -100.0) && (__GET_VAR(data__->SENSOR1.VALUE,) <= 100.0))) {
    __SET_VAR(data__->,SENSOR1.IS_VALID,,__BOOL_LITERAL(TRUE));
  } else {
    __SET_VAR(data__->,SENSOR1.IS_VALID,,__BOOL_LITERAL(FALSE));
  };
  __SET_VAR(data__->,SIMPLE_BOOL,,__GET_VAR(data__->BOOL_ARRAY.value.table[(0) - (0)],));
  __SET_VAR(data__->,SIMPLE_REAL,,((((__GET_VAR(data__->REAL_ARRAY.value.table[(0) - (0)],) + __GET_VAR(data__->REAL_ARRAY.value.table[(1) - (0)],)) + __GET_VAR(data__->REAL_ARRAY.value.table[(2) - (0)],)) + __GET_VAR(data__->REAL_ARRAY.value.table[(3) - (0)],)) / 4.0));

  goto __end;

__end:
  return;
} // MAIN_body__() 





